package com.epam.DAO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.epam.DBUtil.AmaKartDBUtil;
import com.epam.model.CartDetail;
import com.epam.model.Product;

public class ShoppingDaoServiceImpl implements ShoppingDaoService {

	@Override
	public Map<String, HashMap<String, HashMap<String, Product>>> getCategories() {

		return AmaKartDBUtil.categories;

	}

	@Override
	public ArrayList<CartDetail> getcart() {

		return AmaKartDBUtil.cart;
	}

}
