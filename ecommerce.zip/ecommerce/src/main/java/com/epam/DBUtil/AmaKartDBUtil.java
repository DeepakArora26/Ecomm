package com.epam.DBUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.epam.model.CartDetail;
import com.epam.model.Product;

public class AmaKartDBUtil {

	public AmaKartDBUtil() {

	}

	static public Map<String, HashMap<String, HashMap<String, Product>>> categories = new HashMap<String, HashMap<String, HashMap<String, Product>>>();

	static public HashMap<String, HashMap<String, Product>> electronicsSubCategory = new HashMap<String, HashMap<String, Product>>();

	static public HashMap<String, Product> MobileProducts = new HashMap<String, Product>();

	static public HashMap<String, Product> tvProducts = new HashMap<String, Product>();

	static public HashMap<String, HashMap<String, Product>> fashionSubCatehory = new HashMap<String, HashMap<String, Product>>();

	static public HashMap<String, Product> womenProducts = new HashMap<String, Product>();

	static public HashMap<String, Product> mensProducts = new HashMap<String, Product>();

	static public ArrayList<CartDetail> cart = new ArrayList<CartDetail>();

}
