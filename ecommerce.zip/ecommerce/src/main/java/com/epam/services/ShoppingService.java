package com.epam.services;

import java.util.HashMap;
import java.util.Map;

import com.epam.model.Product;

public interface ShoppingService {
	
	void displayCategories();
	
	void displaySubCategories(Map<String, HashMap<String, HashMap<String, Product>>> map, int indexOfCategory);
	
	void displayProducts(HashMap<String, HashMap<String, Product>> SubCatghashMap, int indexOfSubcategory);
	
	void displayProductDetails(HashMap<String, Product> Product, int productselect);
	
	void initializeAmaKartDB();
	
	void displayMenu();
	
	void displayCart();
	
	void checkout();
	
	void modifyCart();
	
	void deleteItemFromCart();

	void modifyItemFromCart();
	
	void calculatePriceDiffAfterModification();
	
}
