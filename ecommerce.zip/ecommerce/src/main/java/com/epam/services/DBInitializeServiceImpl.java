package com.epam.services;

import com.epam.DBUtil.AmaKartDBUtil;
import com.epam.model.Product;

public class DBInitializeServiceImpl implements DBInitializeService{

	@Override
	public void addCategories() {

		AmaKartDBUtil.categories.put("Electronics", AmaKartDBUtil.electronicsSubCategory);
		AmaKartDBUtil.categories.put("Fashion", AmaKartDBUtil.fashionSubCatehory);

	}

	@Override
	public void addSubCategories() {
		AmaKartDBUtil.electronicsSubCategory.put("Phone", AmaKartDBUtil.MobileProducts);
		AmaKartDBUtil.electronicsSubCategory.put("Television", AmaKartDBUtil.tvProducts);

		AmaKartDBUtil.fashionSubCatehory.put("Mens", AmaKartDBUtil.mensProducts);
		AmaKartDBUtil.fashionSubCatehory.put("Womens", AmaKartDBUtil.womenProducts);

	}

	@Override
	public void addProducts() {
		
		Product product = new Product();
		
		product.setProductId("1");
		product.setProductName("Jealous 21 Skinny Jeans");
		product.setProductQuantity(47);
		product.setProductPrice(450);

		AmaKartDBUtil.womenProducts.put(product.getProductName(), product);

		product = new Product();

		product.setProductId("2");
		product.setProductName("Lavie Sling Bag");
		product.setProductQuantity(12);
		product.setProductPrice(846);

		AmaKartDBUtil.womenProducts.put(product.getProductName(), product);
		product = new Product();

		product.setProductId("3");
		product.setProductName("RayBan Basic Black Sunglasses");
		product.setProductQuantity(107);
		product.setProductPrice(599);

		AmaKartDBUtil.womenProducts.put(product.getProductName(), product);
		product = new Product();

		product.setProductId("1");
		product.setProductName("Allen Solly Men's Plain Slim Fit Casual Shirt");
		product.setProductQuantity(20);
		product.setProductPrice(1399);

		AmaKartDBUtil.mensProducts.put(product.getProductName(), product);
		product = new Product();

		product.setProductId("2");
		product.setProductName("Adidas Men's Asweerun Running Shoes");
		product.setProductQuantity(37);
		product.setProductPrice(5599);

		AmaKartDBUtil.mensProducts.put(product.getProductName(), product);
		product = new Product();

		product.setProductId("3");
		product.setProductName("Fastrack Chrono Upgrade Analog Black Dial Men's Watch");
		product.setProductQuantity(5);
		product.setProductPrice(4890);

		AmaKartDBUtil.mensProducts.put(product.getProductName(), product);
		product = new Product();

		product.setProductId("1");
		product.setProductName("OnePlus 55 Inch 4K TV");
		product.setProductQuantity(500);
		product.setProductPrice(69899);

		AmaKartDBUtil.tvProducts.put(product.getProductName(), product);
		product = new Product();

		product.setProductId("2");
		product.setProductName("Mi LED TV 4A PRO 108 cm");
		product.setProductQuantity(310);
		product.setProductPrice(21999);

		AmaKartDBUtil.tvProducts.put(product.getProductName(), product);
		product = new Product();

		product.setProductId("1");
		product.setProductName("Redmi Note 8");
		product.setProductQuantity(75);
		product.setProductPrice(9999);

		AmaKartDBUtil.MobileProducts.put(product.getProductName(), product);
		product = new Product();

		product.setProductId("2");
		product.setProductName("Realme U1 Ambitious Black");
		product.setProductQuantity(40);
		product.setProductPrice(7999);

		AmaKartDBUtil.MobileProducts.put(product.getProductName(), product);
		product = new Product();

		product.setProductId("3");
		product.setProductName("Vivo U20 Blazing Blue");
		product.setProductQuantity(68);
		product.setProductPrice(11990);

		AmaKartDBUtil.MobileProducts.put(product.getProductName(), product);
		product = new Product();

	
	}

}
