package com.epam.model;

public class CartDetail {

	private String productName;
	private int productQuantity;
	private double productPrice;
	private double totalPrice;
	private static double cartTotal;
	private int maxAllowedQuantity;

	public CartDetail() {

	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	

	public double getCartTotal() {
		return cartTotal;
	}

	public void setCartTotal(double cartTotal) {
		this.cartTotal = cartTotal;
	}

	public int getMaxAllowedQuantity() {
		return maxAllowedQuantity;
	}

	public void setMaxAllowedQuantity(int maxAllowedQuantity) {
		this.maxAllowedQuantity = maxAllowedQuantity;
	}

	@Override
	public String toString() {
		return " [productName=" + productName + ", productQuantity=" + productQuantity + ", productPrice="
				+ productPrice + ", totalPrice=" + totalPrice + "]";
	}

}
