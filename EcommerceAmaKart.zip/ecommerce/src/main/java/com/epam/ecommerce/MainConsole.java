package com.epam.ecommerce;

import com.epam.services.ShoppingService;
import com.epam.services.ShoppingServiceImpl;

public class MainConsole {

	static ShoppingService startShopping = new ShoppingServiceImpl();

	public static void main(String[] args) {

		startShopping.displayMenu();
	}

}
