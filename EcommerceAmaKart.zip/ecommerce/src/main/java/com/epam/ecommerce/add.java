package com.epam.ecommerce;

import java.util.Set;

import com.epam.DBUtil.AmaKartDBUtil;
import com.epam.model.Product;
import com.epam.services.ShoppingService;
import com.epam.services.ShoppingServiceImpl;

public class add {

	
	/*
	 * 
	 * 
	 * AmaKartDBUtil.tvProduct.add("Satish");
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * AmaKartDBUtil.categories.forEach((k, v) -> System.out.println(k + " - " +
	 * v));
	 * 
	 * 
	 * 
	 * 
	 * Set<String> keys = AmaKartDBUtil.categories.keySet(); for(String key: keys){
	 * System.out.println(key); }
	 * 
	 * Product addition = new Product();
	 * 
	 * log.info("PCatg");
	 * 
	 * int choiceofcat = input.nextInt();
	 * 
	 * if(choiceofcat==1) { addition.setCategory("Fashion");
	 * 
	 * Set<String> keys1 = AmaKartDBUtil.hashMapF.keySet(); for(String key: keys1){
	 * System.out.println(key); }
	 * 
	 * 
	 * 
	 * log.info("PSUBCatg");
	 * 
	 * int choiceofsubcat = input.nextInt();
	 * 
	 * if(choiceofsubcat==1) { addition.setSubCategory("Womens");
	 * 
	 * }
	 * 
	 * else { addition.setSubCategory("Mens");
	 * 
	 * }
	 * 
	 * 
	 * 
	 * 
	 * log.info("PID"); log.info("PName"); log.info("PPrice"); log.info("Pqty");
	 * 
	 * 
	 * 
	 * 
	 * addition.setProductId(input.next()); addition.setProductName(input.next());
	 * addition.setProductPrice(input.nextInt());
	 * addition.setProductQuantity(input.nextInt());
	 * 
	 * 
	 * 
	 * AmaKartDBUtil.WoMenProductM.put(addition.getProductName(),addition);
	 * 
	 * 
	 * AmaKartDBUtil.MobileProductM.forEach((k, v) -> System.out.println(k + " - " +
	 * v));
	 * 
	 * 
	 * 
	 * AmaKartDBUtil.categories.forEach((k, v) -> System.out.println(k + " - " +
	 * v));
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * } else { addition.setCategory("Electronics");
	 * 
	 * 
	 * Set<String> keys2 = AmaKartDBUtil.hashMap.keySet(); for(String key: keys2){
	 * System.out.println(key); }
	 * 
	 * }
	 */
      
      

}
