package com.epam.services;

public interface DBInitializeService {
	
	
	void addCategories();
	
	void addSubCategories();
	
	void addProducts();

}
