package com.epam.services;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Logger;
import java.awt.List;
import java.util.ArrayList;
import com.epam.DAO.ShoppingDaoService;
import com.epam.DAO.ShoppingDaoServiceImpl;
import com.epam.DBUtil.AmaKartDBUtil;
import com.epam.model.CartDetail;
import com.epam.model.Product;

public class ShoppingServiceImpl implements ShoppingService {

	ShoppingDaoService daoService = new ShoppingDaoServiceImpl();
	static Logger log = Logger.getAnonymousLogger();
	DBInitializeService dbInitialize = new DBInitializeServiceImpl();
	static Scanner input = new Scanner(System.in);
	String userSelection;
	int bulletpoint;
	

	@Override
	public void displayCategories() {

		log.info("Choose The Category");
		bulletpoint = 1;

		for (String key : daoService.getCategories().keySet()) {
			log.info(bulletpoint++ + "." + key);
		}

		try {
			displaySubCategories(daoService.getCategories(), input.nextInt());
		}

		catch (InputMismatchException e) {
			log.info("Wrong Selection");
			input.next();
			displayCategories();
		}

		catch (IndexOutOfBoundsException e) {
			log.info("Wrong Selection");
			displayCategories();
		}

	}

	@Override
	public void displaySubCategories(Map<String, HashMap<String, HashMap<String, Product>>> categoriesMap,
			int indexOfCategory) {

		log.info("Choose The Sub Category");
		bulletpoint = 1;

		for (String key : categoriesMap.get(categoriesMap.keySet().toArray()[indexOfCategory - 1]).keySet()) {
			log.info(bulletpoint++ + "." + key);
		}

		displayProducts(categoriesMap.get(categoriesMap.keySet().toArray()[indexOfCategory - 1]), input.nextInt());

	}

	@Override
	public void displayProducts(HashMap<String, HashMap<String, Product>> SubCategoryMap, int indexOfSubcategory) {

		log.info("Choose The Product");
		bulletpoint = 1;

		for (String key : SubCategoryMap.get(SubCategoryMap.keySet().toArray()[indexOfSubcategory - 1]).keySet()) {
			log.info(bulletpoint++ + "." + key);
		}

		displayProductDetails(SubCategoryMap.get(SubCategoryMap.keySet().toArray()[indexOfSubcategory - 1]),
				input.nextInt());

	}

	@Override
	public void displayProductDetails(HashMap<String, Product> Product, int productselect) {

		Product selectProduct = Product.get(Product.keySet().toArray()[productselect - 1]);
		CartDetail productsInCart = new CartDetail();
		log.info("" + selectProduct);

		log.info("Add To Cart : Y/N");
		userSelection = input.next();
		if (userSelection.equalsIgnoreCase("Y")) {

			log.info("ENter The Qty  info : Max Qty-> " + selectProduct.getProductQuantity());
			int desiredQuantity = input.nextInt();
			if (desiredQuantity > selectProduct.getProductQuantity()) {
				log.info("You cannot buy more than :" + selectProduct.getProductQuantity() + " Units");
				displayMenu();
			}
			productsInCart.setProductQuantity(desiredQuantity);
			productsInCart.setMaxAllowedQuantity(selectProduct.getProductQuantity());
			productsInCart.setProductName(selectProduct.getProductName());
			productsInCart.setProductPrice(selectProduct.getProductPrice());
			productsInCart.setTotalPrice(productsInCart.getProductPrice() * productsInCart.getProductQuantity());
			productsInCart.setCartTotal(productsInCart.getCartTotal() + productsInCart.getTotalPrice());
			System.out.println();
			AmaKartDBUtil.cart.add(productsInCart);
			displayCart();
			displayMenu();
		}

		else if (userSelection.equalsIgnoreCase("N")) {

			displayMenu();

		}

		else {
			log.info("Wrong Selection");

			displayMenu();

		}

	}

	@Override
	public void initializeAmaKartDB() {

		dbInitialize.addCategories();
		dbInitialize.addSubCategories();
		dbInitialize.addProducts();

	}

	@Override
	public void displayMenu() {

		initializeAmaKartDB();

		log.info("Welcome to AmaKart Shopping Portal");
		log.info("Choose your Option");
		log.info("1.Add Data");
		log.info("2.Shopping");
		log.info("3.View Cart");
		log.info("4.Exit / CheckOut");

		userSelection = input.next();

		switch (userSelection) {

		case "1":
			break;
		case "2":
			displayCategories();
			break;
		case "3":
			displayCart();
			break;
		case "4":
			checkout();
			break;
		default:
			log.info("Wrong Selection");
			displayMenu();
		}

	}

	@Override

	public void displayCart() {

		if (daoService.getcart().isEmpty())
			log.info("Your cart is EMPTY !!");
		else {
			daoService.getcart().forEach(productDetail -> {
				log.info("" + productDetail);
			});

			log.info("" + daoService.getcart().get(0).getCartTotal());

			log.info("Do you want to Modify Cart ? Y/N");
			switch (input.next()) {
			case "Y":
				modifyCart();
			case "N":
				displayMenu();
			default:
				log.info("Wrong Input");
			}

		}

		displayMenu();
	}

	@Override
	public void checkout() {

		if (daoService.getcart().isEmpty()) {

			log.info("Thanks for Visiting AmaKart");

		}

		else {
			log.info("Your cart contains the following items.");

			displayCart();

			log.info("Would you like to Checkout : Y/N ? If N it will clear your cart and you will exit the portal");

			userSelection = input.next();

			if (userSelection.equalsIgnoreCase("Y")) {

				log.info("Thanks for Shopping with AmaKart");
				log.info("Here are your Order Details");
				displayCart();
				System.exit(0);
			}

			else if (userSelection.equalsIgnoreCase("N")) {

				log.info("Thanks for Visiting AmaKart");
				displayMenu();
			}
		}

		input.close();
	}

	@Override
	public void modifyCart() {

		log.info("CHoose the Option");
		log.info("1. Delete the item from Cart");
		log.info("2. Modify the quantity of the item");

		userSelection = input.next();

		switch (userSelection) {
		case "1":
			deleteItemFromCart();
		case "2":
			modifyItemFromCart();
		default:
			log.info("Wrong Input");
			displayMenu();
		}

	}

	@Override
	public void deleteItemFromCart() {

		log.info("Select the item you want to Delete :");
		
	    ArrayList<CartDetail> currentCart = new ArrayList<CartDetail>();

		currentCart = daoService.getcart();

		currentCart.forEach(productDetail -> {
			log.info("" + productDetail);
		});

		currentCart.remove(input.nextInt() - 1);
		log.info("Item Successfully Deleted. Your Updated Cart");
		displayCart();
	}

	@Override
	public void modifyItemFromCart() {
		log.info("Select the item you want to Modify :");

		
		daoService.getcart().forEach(productDetail -> {
			log.info("" + productDetail);
		});

		int selection = input.nextInt();
		
		CartDetail productToBeDeleted = new CartDetail();
		
		productToBeDeleted = daoService.getcart().get(selection - 1);
		int differenceInQuantity;
		
		log.info("Enter the Updates Quantity");

		int updatedQuantity = input.nextInt();
		if (updatedQuantity > productToBeDeleted.getProductQuantity()) {
			differenceInQuantity = updatedQuantity - productToBeDeleted.getProductQuantity();
		}

		else {
			differenceInQuantity = productToBeDeleted.getProductQuantity() - updatedQuantity;
		}

		double differenceInPrice = differenceInQuantity * productToBeDeleted.getProductPrice();
		if (updatedQuantity > productToBeDeleted.getMaxAllowedQuantity()) {
			log.info("You cannot buy < 0 or more than "
					+ productToBeDeleted.getMaxAllowedQuantity() + "");
			displayMenu();
		}
		productToBeDeleted.setProductQuantity(updatedQuantity);
		daoService.getcart().get(selection - 1)
				.setCartTotal(productToBeDeleted.getCartTotal() - differenceInPrice);

		displayMenu();

	}

	@Override
	public void calculatePriceDiffAfterModification() {
		// TODO Auto-generated method stub
		
	}

	

}
