package com.epam.DAO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.epam.model.CartDetail;
import com.epam.model.Product;

public interface ShoppingDaoService {

	Map<String, HashMap<String, HashMap<String, Product>>> getCategories();
	
	ArrayList<CartDetail> getcart();

}
