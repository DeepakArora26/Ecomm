package com.epam.ecommerce;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.logging.Logger;

import com.epam.DBUtil.AmaKartDBUtil;
import com.epam.model.Product;

public class MainConsole {

	static Logger log = Logger.getAnonymousLogger();
	static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {

		int selection;

		log.info("Welcome to AmaKart Shopping Portal");
		


		do {
			log.info("Choose your Option");
			log.info("1.Add Data");
			log.info("2.Exit");
			selection = input.nextInt();
			switch (selection) {

			case 1:
				AmaKartDBUtil.tvProduct.add("Satish");
				AmaKartDBUtil.hashMap.put("Phone", AmaKartDBUtil.MobileProduct);
				AmaKartDBUtil.hashMap.put("Television", AmaKartDBUtil.tvProduct);
				AmaKartDBUtil.hashMapF.put("Mens", AmaKartDBUtil.MenProduct);
				AmaKartDBUtil.hashMapF.put("Womens", AmaKartDBUtil.WoMenProduct);
				AmaKartDBUtil.categories.put("Electronics",AmaKartDBUtil.hashMap);
				AmaKartDBUtil.categories.put("Fashion",AmaKartDBUtil.hashMapF);
				AmaKartDBUtil.categories.forEach((k, v) -> System.out.println(k + " - " + v));
				break;
			case 2:
				log.info("Thanks for Visiting");
				System.exit(0);
				break;

			default:
				log.info("Wrong Selection");
			}
		} while (selection != 1 || selection != 2);
		input.close();

	}




}
