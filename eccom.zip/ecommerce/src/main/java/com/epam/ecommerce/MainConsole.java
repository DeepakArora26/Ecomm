package com.epam.ecommerce;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale.Category;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.Logger;

import com.epam.DBUtil.AmaKartDBUtil;
import com.epam.model.Product;
import com.epam.services.ShoppingService;
import com.epam.services.ShoppingServiceImpl;

public class MainConsole {

	static Logger log = Logger.getAnonymousLogger();
	static Scanner input = new Scanner(System.in);
	
	
	

	public static void main(String[] args) {
		

		



		int selection;
		ShoppingService service= new ShoppingServiceImpl();

		log.info("Welcome to AmaKart Shopping Portal");
		
		
		
		
		AmaKartDBUtil.hashMap.put("Phone", AmaKartDBUtil.MobileProductM);
	    AmaKartDBUtil.hashMap.put("Television", AmaKartDBUtil.tvProductM);

	    
		AmaKartDBUtil.hashMapF.put("Mens", AmaKartDBUtil.MenProductM);
		AmaKartDBUtil.hashMapF.put("Womens", AmaKartDBUtil.WoMenProductM);
		
		AmaKartDBUtil.categories.put("Electronics",AmaKartDBUtil.hashMap);
		AmaKartDBUtil.categories.put("Fashion",AmaKartDBUtil.hashMapF);
		
		
		
		
		
		


		do {
			log.info("Choose your Option");
			log.info("1.Add Data");
			log.info("2.Shopping");
			log.info("3.Exit");
			selection = input.nextInt();
			switch (selection) {

			case 1:
				break;
			case 2:
			
			service.getCategories();
			log.info("Choose The Category");
			
			
			
			
			
			service.getSubCategories(input.nextInt());
				break;
			case 3:
				log.info("Thanks for Visiting");
				System.exit(0);
				break;

			default:
				log.info("Wrong Selection");
			}
		} while (selection != 1 || selection != 2);
		input.close();

	}






	




}
