package com.epam.DAO;

import java.util.HashMap;
import java.util.Map;

import com.epam.DBUtil.AmaKartDBUtil;
import com.epam.model.Product;

public class ShoppingDaoServiceImpl implements ShoppingDaoService {

	@Override
	public Map<String, HashMap<String, HashMap<String, Product>>> displayCategories() {

		return AmaKartDBUtil.categories;
	}

	@Override
	public HashMap<String, HashMap<String, Product>> displaySubCategories(int indexOfCategory) {
		
		Map<String, HashMap<String, HashMap<String, Product>>> a =AmaKartDBUtil.categories;
		
		
		
		return a.get(a.keySet().toArray()[indexOfCategory-1]);
	}


	@Override
	public HashMap<String, Product> displayProducts(String productsOfSubcategory) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product displayProductDetails(String productName) {
		// TODO Auto-generated method stub
		return null;
	}



	
}
