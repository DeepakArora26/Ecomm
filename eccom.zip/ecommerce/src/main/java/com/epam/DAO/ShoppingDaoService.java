package com.epam.DAO;

import java.util.HashMap;
import java.util.Map;

import com.epam.model.Product;

public interface ShoppingDaoService {

	HashMap<String, HashMap<String, Product>> displaySubCategories(int indexOfCategory); 

	Map<String, HashMap<String, HashMap<String, Product>>> displayCategories();

	HashMap<String, Product> displayProducts(String productsOfSubcategory);

	Product displayProductDetails(String productName);

}
