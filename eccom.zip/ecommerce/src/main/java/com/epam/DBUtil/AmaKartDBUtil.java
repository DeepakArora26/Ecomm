package com.epam.DBUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AmaKartDBUtil {

	public AmaKartDBUtil() {

	}

	
	  static public List<String> MobileProduct = new ArrayList<String>(Arrays.asList(new String[] {
	  "Iphone", "One+", "Xiaomi", "I-ball" }));
	  

	  static public List<String> tvProduct = new ArrayList<String>(Arrays.asList(new String[] {
	  "Sony", "One+", "Xiaomi", "Onida" }));
	  

	  static public List<String> MenProduct = new ArrayList<String>(Arrays.asList(new String[] {
	  "Shirt", "Jeans", "SHoes", "FLip-FLops" }));
	  
	  static public List<String> WoMenProduct = new ArrayList<String>(Arrays.asList(new String[] {
	  "T-Shirt", "Accessories", "Sunglasses" }));
	  
	  
	  static public HashMap<String, List<String>> hashMap = new HashMap<String, List<String>>();
	  
	  static public HashMap<String, List<String>> hashMapF = new HashMap<String, List<String>>();
	  
	  static public Map<String, HashMap<String, List<String>>> categories = new HashMap<String,HashMap<String,List<String>>>();
	
} 
