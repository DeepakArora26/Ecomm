package com.epam.DBUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.epam.model.Product;

public class AmaKartDBUtil {

	public AmaKartDBUtil() {

	}
	
	
	static public HashMap<String, Product> hashMapFP = new HashMap<String, Product>();
	
	
	static public HashMap<String, Product> WoMenProductM = new HashMap<String, Product>();
	
	static public HashMap<String, Product> MobileProductM = new HashMap<String, Product>();
	
	
	static public HashMap<String, Product>tvProductM = new HashMap<String, Product>();
	
	static public HashMap<String, Product>MenProductM = new HashMap<String, Product>();
	
	
	
	
	
	static public HashMap<String, HashMap<String, Product>> hashMap = new HashMap<String, HashMap<String, Product>>();

	static public HashMap<String, HashMap<String, Product>> hashMapF = new HashMap<String, HashMap<String, Product>>();

	

	static public Map<String, HashMap<String, HashMap<String, Product>>> categories = new HashMap<String, HashMap<String, HashMap<String, Product>>>();

}
