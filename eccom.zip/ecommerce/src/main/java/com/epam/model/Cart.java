package com.epam.model;

public class Cart {

	private String productName;
	private String productQuantity;
	private String productPrice;
	private String totalPrice;

	public Cart() {

	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(String productQuantity) {
		this.productQuantity = productQuantity;
	}

	public String getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(String productPrice) {
		this.productPrice = productPrice;
	}

	public String getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}

	@Override
	public String toString() {
		return "Cart [productName=" + productName + ", productQuantity=" + productQuantity + ", productPrice="
				+ productPrice + ", totalPrice=" + totalPrice + "]";
	}

}
