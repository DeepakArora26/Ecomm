package com.epam.services;

public interface ShoppingService {
	
	void getCategories();
	
	void getSubCategories(int indexOfCategory);
	
	void getProducts(String productsOfSubcategory);
	
	void getProductDetails(String productName);

}
