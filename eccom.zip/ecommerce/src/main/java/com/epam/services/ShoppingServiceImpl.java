package com.epam.services;

import java.util.Set;

import com.epam.DAO.ShoppingDaoService;
import com.epam.DAO.ShoppingDaoServiceImpl;
import com.epam.DBUtil.AmaKartDBUtil;

public class ShoppingServiceImpl implements ShoppingService {

	ShoppingDaoService daoService;

	public ShoppingServiceImpl() {
		daoService = new ShoppingDaoServiceImpl();
	}

	@Override
	public void getCategories() {
		int i = 1;
		for (String key : daoService.displayCategories().keySet()) {

			System.out.println(i++ + "." + key);
		}

	}

	@Override
	public void getSubCategories(int indexOfCategory) {
		daoService.displaySubCategories(indexOfCategory);
		int i = 1;
		for (String key : daoService.displaySubCategories(indexOfCategory).keySet()) {

			System.out.println(i++ + "." + key);
		}

	}

	@Override
	public void getProducts(String productsOfSubcategory) {
		// TODO Auto-generated method stub

	}

	@Override
	public void getProductDetails(String productName) {
		// TODO Auto-generated method stub

	}

}
